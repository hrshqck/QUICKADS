import svgPaths from "./svg-937576clnq";
import { imgGroup } from "./svg-xgd5m";

function Group1() {
  return (
    <div className="absolute bottom-[-9.33%] left-[-21.04%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[303px_0px] mask-size-[1440px_900px] right-[-15.21%] top-0" data-name="Group" style={{ maskImage: `url('${imgGroup}')` }}>
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1962 984">
        <g id="Group">
          <path d="M1743 0H303V900H1743V0Z" fill="var(--fill-0, white)" id="Vector" />
          <path d={svgPaths.p13a6bc0} fill="var(--fill-0, #6046E9)" fillOpacity="0.61" id="Vector_2" />
          <path d={svgPaths.p3a301370} fill="var(--fill-0, #6046E9)" fillOpacity="0.61" id="Vector_3" />
          <path d={svgPaths.p34e75600} fill="var(--fill-0, #FF00DD)" fillOpacity="0.14" id="Vector_4" />
          <g id="Group_2">
            <path d="M1743 1H303V900H1743V1Z" fill="var(--fill-0, white)" fillOpacity="0.2" id="Vector_5" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function ClipPathGroup() {
  return (
    <div className="absolute contents inset-0" data-name="Clip path group">
      <Group1 />
    </div>
  );
}

export default function Frame7585326081() {
  return (
    <div className="relative size-full" data-name="Frame 758532608 1">
      <ClipPathGroup />
    </div>
  );
}