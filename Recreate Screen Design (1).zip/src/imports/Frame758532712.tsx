// QuickAds Frame Component - Main pricing and features layout
import { Button } from "../components/ui/button";
import { Card } from "../components/ui/card";
import svgPaths from "./svg-u9cenhrg0l";

export function Frame758532712() {
  return (
    <div className="w-full min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* QuickAds Hero Section */}
      <div className="relative p-8 bg-gradient-to-br from-orange-500 via-red-500 to-pink-600 overflow-hidden">
        {/* Decorative elements */}
        <div className="absolute inset-0 bg-black/10"></div>
        
        <div className="relative z-10 text-center text-white max-w-4xl mx-auto">
          <h1 className="text-5xl font-bold mb-4">QuickAds AI Platform</h1>
          <p className="text-xl mb-8 opacity-90">Create stunning ads in minutes with AI-powered tools</p>
          
          {/* Feature highlights */}
          <div className="flex justify-center items-center gap-8 mb-8">
            <div className="flex items-center gap-3">
              <div className="h-[7px] w-[12px] flex-shrink-0">
                <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 8">
                  <path d={svgPaths.pdf76300} stroke="white" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </div>
              <span className="text-sm font-semibold">AI Video Generation</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="h-[7px] w-[14px] flex-shrink-0">
                <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 8">
                  <path d={svgPaths.p143fe00} stroke="white" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </div>
              <span className="text-sm font-semibold">Smart Templates</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="h-[7px] w-[14px] flex-shrink-0">
                <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 8">
                  <path d={svgPaths.p9ccfb00} stroke="white" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </div>
              <span className="text-sm font-semibold">Brand Automation</span>
            </div>
          </div>
          
          <Button className="bg-white text-gray-900 hover:bg-gray-100 px-8 py-3 text-lg font-semibold">
            Start Creating
          </Button>
        </div>
      </div>

      {/* Pricing Cards Section */}
      <div className="p-8 max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-white mb-4">Choose Your Plan</h2>
          <p className="text-gray-400">Scale your advertising with the right tools for your business</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Starter Plan */}
          <Card className="p-6 bg-gradient-to-br from-slate-800 to-slate-700 border-slate-600 text-white">
            <div className="mb-6">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-lg flex items-center justify-center mb-4">
                <span className="text-2xl">🚀</span>
              </div>
              <h3 className="text-xl font-bold mb-2">Starter</h3>
              <p className="text-gray-400 text-sm mb-4">Perfect for small businesses</p>
              <div className="text-3xl font-bold">$29<span className="text-lg text-gray-400">/mo</span></div>
            </div>
            
            <div className="space-y-3 mb-6">
              <div className="flex items-center gap-3">
                <div className="h-[7px] w-[12px] flex-shrink-0">
                  <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 8">
                    <path d={svgPaths.pdf76300} stroke="#22d3ee" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
                <span className="text-sm">50 AI-generated ads</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="h-[7px] w-[12px] flex-shrink-0">
                  <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 8">
                    <path d={svgPaths.pdf76300} stroke="#22d3ee" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
                <span className="text-sm">Basic templates</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="h-[7px] w-[12px] flex-shrink-0">
                  <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 8">
                    <path d={svgPaths.pdf76300} stroke="#22d3ee" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
                <span className="text-sm">HD exports</span>
              </div>
            </div>
            
            <Button className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600">
              Get Started
            </Button>
          </Card>

          {/* Pro Plan */}
          <Card className="p-6 bg-gradient-to-br from-orange-500/20 to-red-500/20 border-orange-500/50 text-white relative">
            <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
              <span className="bg-gradient-to-r from-orange-500 to-red-500 text-white px-4 py-1 rounded-full text-xs font-semibold">
                Most Popular
              </span>
            </div>
            
            <div className="mb-6">
              <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-red-500 rounded-lg flex items-center justify-center mb-4">
                <span className="text-2xl">⭐</span>
              </div>
              <h3 className="text-xl font-bold mb-2">Pro</h3>
              <p className="text-gray-400 text-sm mb-4">For growing businesses</p>
              <div className="text-3xl font-bold">$79<span className="text-lg text-gray-400">/mo</span></div>
            </div>
            
            <div className="space-y-3 mb-6">
              <div className="flex items-center gap-3">
                <div className="h-[7px] w-[12px] flex-shrink-0">
                  <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 8">
                    <path d={svgPaths.pdf76300} stroke="#f97316" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
                <span className="text-sm">Unlimited AI ads</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="h-[7px] w-[12px] flex-shrink-0">
                  <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 8">
                    <path d={svgPaths.pdf76300} stroke="#f97316" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
                <span className="text-sm">Premium templates</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="h-[7px] w-[12px] flex-shrink-0">
                  <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 8">
                    <path d={svgPaths.pdf76300} stroke="#f97316" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
                <span className="text-sm">4K exports</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="h-[7px] w-[12px] flex-shrink-0">
                  <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 8">
                    <path d={svgPaths.pdf76300} stroke="#f97316" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
                <span className="text-sm">Brand kit integration</span>
              </div>
            </div>
            
            <Button className="w-full bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600">
              Upgrade to Pro
            </Button>
          </Card>

          {/* Enterprise Plan */}
          <Card className="p-6 bg-gradient-to-br from-slate-800 to-slate-700 border-slate-600 text-white">
            <div className="mb-6">
              <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center mb-4">
                <span className="text-2xl">🏢</span>
              </div>
              <h3 className="text-xl font-bold mb-2">Enterprise</h3>
              <p className="text-gray-400 text-sm mb-4">For large organizations</p>
              <div className="text-3xl font-bold">$199<span className="text-lg text-gray-400">/mo</span></div>
            </div>
            
            <div className="space-y-3 mb-6">
              <div className="flex items-center gap-3">
                <div className="h-[7px] w-[12px] flex-shrink-0">
                  <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 8">
                    <path d={svgPaths.pdf76300} stroke="#a855f7" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
                <span className="text-sm">Everything in Pro</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="h-[7px] w-[12px] flex-shrink-0">
                  <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 8">
                    <path d={svgPaths.pdf76300} stroke="#a855f7" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
                <span className="text-sm">Advanced analytics</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="h-[7px] w-[12px] flex-shrink-0">
                  <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 8">
                    <path d={svgPaths.pdf76300} stroke="#a855f7" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
                <span className="text-sm">Team collaboration</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="h-[7px] w-[12px] flex-shrink-0">
                  <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 8">
                    <path d={svgPaths.pdf76300} stroke="#a855f7" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
                <span className="text-sm">Priority support</span>
              </div>
            </div>
            
            <Button className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600">
              Contact Sales
            </Button>
          </Card>
        </div>
      </div>
    </div>
  );
}