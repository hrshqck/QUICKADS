function Frame758532692() {
  return <div className="absolute h-[22px] left-1/2 translate-x-[-50%] translate-y-[-50%] w-[215px]" style={{ top: "calc(50% + 0.5px)" }} />;
}

function Frame758532693() {
  return (
    <div className="h-[39px] relative shrink-0 w-full">
      <Frame758532692 />
    </div>
  );
}

function Group151() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0 text-black">
      <div className="[grid-area:1_/_1] flex flex-col font-['DM_Sans:Medium',_sans-serif] font-medium h-[17px] justify-center ml-0 mt-[8.5px] relative text-[22px] translate-y-[-50%] w-[103.333px]" style={{ fontVariationSettings: "'opsz' 14" }}>
        <p className="leading-[18px]">Starter</p>
      </div>
      <div className="[grid-area:1_/_1] flex flex-col font-['DM_Sans:ExtraLight',_sans-serif] font-extralight justify-center ml-0 mt-[48px] relative text-[0px] translate-y-[-50%] w-[155px]" style={{ fontVariationSettings: "'opsz' 14" }}>
        <p className="leading-[44px]">
          <span className="font-['DM_Sans:Light',_sans-serif] font-light text-[25px]" style={{ fontVariationSettings: "'opsz' 14" }}>
            $
          </span>
          <span className="font-['DM_Sans:ExtraLight',_sans-serif] font-extralight text-[20px]" style={{ fontVariationSettings: "'opsz' 14" }}>
            63
          </span>
          <span className="font-['DM_Sans:Bold',_sans-serif] font-bold text-[20px]" style={{ fontVariationSettings: "'opsz' 14" }}>
            {" "}
          </span>
          <span className="font-['DM_Sans:Light',_sans-serif] font-light text-[20px]" style={{ fontVariationSettings: "'opsz' 14" }}>
            /
          </span>
          <span className="font-['DM_Sans:ExtraLight',_sans-serif] font-extralight text-[20px]" style={{ fontVariationSettings: "'opsz' 14" }}>
            Per Month
          </span>
        </p>
      </div>
    </div>
  );
}

function Frame758532679() {
  return (
    <div className="bg-gradient-to-b from-[rgba(180,165,251,0)] h-[108px] relative rounded-tl-[13px] rounded-tr-[13px] shrink-0 to-[#ececec] via-0% via-[rgba(201,192,245,0)] w-full">
      <div className="overflow-clip relative size-full">
        <div className="box-border content-stretch flex flex-col h-[108px] items-start justify-start pb-[15px] pt-[22px] px-[16px] relative w-full">
          <Group151 />
        </div>
      </div>
      <div className="absolute inset-0 pointer-events-none shadow-[0px_4px_9.3px_-3px_inset_rgba(255,255,255,0.6)]" />
    </div>
  );
}

function Frame758532704() {
  return (
    <div className="bg-gradient-to-r box-border content-stretch flex from-[#6046e9] gap-[10px] h-[24px] items-center justify-center overflow-clip px-[10px] py-[2px] relative rounded-[6px] shrink-0 to-[rgba(96,70,233,0.67)] w-[113px]">
      <div className="flex flex-col font-['DM_Sans:SemiBold',_sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[9px] text-nowrap text-white" style={{ fontVariationSettings: "'opsz' 14" }}>
        <p className="leading-[27px] whitespace-pre">Select Plan</p>
      </div>
    </div>
  );
}

function Frame758532706() {
  return (
    <div className="content-stretch flex flex-col h-[194px] items-center justify-center relative shrink-0 w-full">
      <div className="flex flex-col font-['DM_Sans:Bold',_sans-serif] font-bold h-[16px] justify-center leading-[0] relative shrink-0 text-[#0b0707] text-[9px] text-center w-[200px]" style={{ fontVariationSettings: "'opsz' 14" }}>
        <p className="leading-[27px]">Plan Highlights</p>
      </div>
      <div className="flex flex-col font-['Inter:Light',_sans-serif] font-light h-[138px] justify-center leading-[0] not-italic relative shrink-0 text-[0px] text-black text-center w-full whitespace-pre-wrap">
        <p className="leading-[27px] mb-0 text-[9px]">
          <span className="font-['DM_Sans:Medium',_sans-serif] font-medium" style={{ fontVariationSettings: "'opsz' 14" }}>{` Content Downloads`}</span>
          <span className="font-['DM_Sans:Light',_sans-serif] font-light" style={{ fontVariationSettings: "'opsz' 14" }}>
            {`                     10/month`}
            <br aria-hidden="true" />
          </span>
          <span className="font-['DM_Sans:Medium',_sans-serif] font-medium" style={{ fontVariationSettings: "'opsz' 14" }}>
            AI Video Generation
          </span>
          <span className="font-['DM_Sans:Light',_sans-serif] font-light" style={{ fontVariationSettings: "'opsz' 14" }}>
            {`           30 mins/month`}
            <br aria-hidden="true" />
          </span>
          <span className="font-['DM_Sans:Medium',_sans-serif] font-medium" style={{ fontVariationSettings: "'opsz' 14" }}>{`Virtual Photoshoots  `}</span>
          <span className="font-['DM_Sans:Light',_sans-serif] font-light" style={{ fontVariationSettings: "'opsz' 14" }}>
            {`                               30`}
            <br aria-hidden="true" />
          </span>
          <span className="font-['DM_Sans:Medium',_sans-serif] font-medium" style={{ fontVariationSettings: "'opsz' 14" }}>
            Video Quality
          </span>
          <span className="font-['DM_Sans:Light',_sans-serif] font-light" style={{ fontVariationSettings: "'opsz' 14" }}>{`                      SD (1920x1080)`}</span>
        </p>
        <p className="leading-[27px] text-[9px]">
          <span className="font-['DM_Sans:Medium',_sans-serif] font-medium" style={{ fontVariationSettings: "'opsz' 14" }}>
            Brand Kits
          </span>
          <span className="font-['DM_Sans:Light',_sans-serif] font-light" style={{ fontVariationSettings: "'opsz' 14" }}>{`                                                    3`}</span>
        </p>
      </div>
      <Frame758532704 />
    </div>
  );
}

function Frame758532676() {
  return (
    <div className="bg-white box-border content-stretch flex flex-col h-[300px] items-start justify-start overflow-clip relative rounded-[13px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] shrink-0">
      <Frame758532679 />
      <Frame758532706 />
    </div>
  );
}

function Frame758532700() {
  return <div className="absolute h-[186px] left-[4.95px] top-[114px] w-[215px]" />;
}

function Group174() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-0 mt-0 place-items-start relative">
      <div className="[grid-area:1_/_1] flex flex-col font-['DM_Sans:Light',_sans-serif] font-light h-[122px] justify-center ml-0 mt-[61px] relative text-[9px] text-black translate-y-[-50%] w-[223.25px]" style={{ fontVariationSettings: "'opsz' 14" }}>
        <p className="leading-[27px] whitespace-pre-wrap">
          <span className="font-['DM_Sans:Medium',_sans-serif] font-medium" style={{ fontVariationSettings: "'opsz' 14" }}>{`   Content Downloads      `}</span>{" "}
          <span>
            60/month
            <br aria-hidden="true" />
          </span>{" "}
          <span className="font-['DM_Sans:Medium',_sans-serif] font-medium" style={{ fontVariationSettings: "'opsz' 14" }}>{`AI Video Generation                      `}</span>
          <span>
            {` 60 mins/month`}
            <br aria-hidden="true" />
          </span>{" "}
          <span className="font-['DM_Sans:Medium',_sans-serif] font-medium" style={{ fontVariationSettings: "'opsz' 14" }}>
            Virtual Photoshoots
          </span>
          <span className="font-['DM_Sans:Bold',_sans-serif] font-bold" style={{ fontVariationSettings: "'opsz' 14" }}>
            {" "}
          </span>{" "}
          <span>{`      8`}</span>
          <span>
            0<br aria-hidden="true" />{" "}
          </span>
          <span className="font-['DM_Sans:Bold',_sans-serif] font-bold" style={{ fontVariationSettings: "'opsz' 14" }}>
            {" "}
          </span>
          <span className="font-['DM_Sans:Medium',_sans-serif] font-medium" style={{ fontVariationSettings: "'opsz' 14" }}>{`Video Quality         `}</span>{" "}
          <span>
            {`  HD (1920x1080p)`}
            <br aria-hidden="true" />
          </span>{" "}
          <span className="font-['DM_Sans:Bold',_sans-serif] font-bold" style={{ fontVariationSettings: "'opsz' 14" }}>
            B
          </span>
          <span className="font-['DM_Sans:Medium',_sans-serif] font-medium" style={{ fontVariationSettings: "'opsz' 14" }}>{`rand Kits  `}</span>
          <span className="font-['DM_Sans:Bold',_sans-serif] font-bold" style={{ fontVariationSettings: "'opsz' 14" }}>
            {" "}
          </span>{" "}
          <span>{`5  `}</span>
        </p>
      </div>
    </div>
  );
}

function Group172() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <Group174 />
    </div>
  );
}

function Frame176() {
  return (
    <div className="content-stretch flex gap-[10px] h-[152px] items-center justify-center relative shrink-0 w-full">
      <Group172 />
    </div>
  );
}

function Frame758532708() {
  return (
    <div className="bg-gradient-to-r box-border content-stretch flex from-[#6046e9] gap-[10px] h-[29px] items-center justify-center overflow-clip px-[10px] py-[2px] relative rounded-[6px] shrink-0 to-[rgba(96,70,233,0.67)] w-[158px]">
      <div className="flex flex-col font-['DM_Sans:SemiBold',_sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[9px] text-nowrap text-white" style={{ fontVariationSettings: "'opsz' 14" }}>
        <p className="leading-[27px] whitespace-pre">Select Plan</p>
      </div>
    </div>
  );
}

function Frame758532705() {
  return (
    <div className="absolute content-stretch flex flex-col items-center justify-start left-[3.95px] top-[111px] w-[215px]">
      <div className="flex flex-col font-['DM_Sans:Bold',_sans-serif] font-bold h-[20px] justify-center leading-[0] relative shrink-0 text-[#0b0707] text-[9px] text-center w-full" style={{ fontVariationSettings: "'opsz' 14" }}>
        <p className="leading-[27px]">Plan Highlights</p>
      </div>
      <Frame176 />
      <Frame758532708 />
    </div>
  );
}

function Frame758532648() {
  return (
    <div className="[grid-area:1_/_1] bg-white h-[320px] ml-0 mt-0 relative rounded-[13px] w-[222.951px]">
      <div className="h-[320px] overflow-clip relative w-[222.951px]">
        <Frame758532700 />
        <Frame758532705 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#0037ff] border-solid inset-[-0.5px] pointer-events-none rounded-[13.5px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)]" />
    </div>
  );
}

function Group161() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-[0.05px] mt-0 place-items-start relative">
      <Frame758532648 />
    </div>
  );
}

function Frame758532680() {
  return (
    <div className="content-stretch flex flex-col h-[86px] items-start justify-center leading-[0] relative shrink-0 w-full">
      <div className="[text-shadow:rgba(96,70,233,0.55)_0px_3px_5.2px] flex flex-col font-['DM_Sans:Light',_sans-serif] font-light justify-center min-w-full relative shrink-0 text-[10px] text-[rgba(255,255,255,0)] text-right" style={{ width: "min-content", fontVariationSettings: "'opsz' 14" }}>
        <p className="leading-[18px]">{`Recommended `}</p>
      </div>
      <div className="flex flex-col font-['DM_Sans:Medium',_sans-serif] font-medium h-[33px] justify-center relative shrink-0 text-[25px] text-black tracking-[-0.25px] w-full" style={{ fontVariationSettings: "'opsz' 14" }}>
        <p className="leading-[64px]">Pro Plan</p>
      </div>
      <div className="flex flex-col font-['DM_Sans:ExtraLight',_sans-serif] font-extralight justify-center relative shrink-0 text-[0px] text-black w-[186px]" style={{ fontVariationSettings: "'opsz' 14" }}>
        <p className="leading-[44px]">
          <span className="font-['DM_Sans:Light',_sans-serif] font-light text-[25px]" style={{ fontVariationSettings: "'opsz' 14" }}>
            $
          </span>
          <span className="font-['DM_Sans:ExtraLight',_sans-serif] font-extralight text-[22px]" style={{ fontVariationSettings: "'opsz' 14" }}>
            79
          </span>
          <span className="font-['DM_Sans:Bold',_sans-serif] font-bold text-[22px]" style={{ fontVariationSettings: "'opsz' 14" }}>
            {" "}
          </span>
          <span className="font-['DM_Sans:Light',_sans-serif] font-light text-[22px]" style={{ fontVariationSettings: "'opsz' 14" }}>
            /
          </span>
          <span className="font-['DM_Sans:ExtraLight',_sans-serif] font-extralight text-[22px]" style={{ fontVariationSettings: "'opsz' 14" }}>
            Per Month
          </span>
        </p>
      </div>
    </div>
  );
}

function Frame758532681() {
  return (
    <div className="[grid-area:1_/_1] bg-gradient-to-b box-border content-stretch flex flex-col from-[rgba(96,70,233,0.19)] gap-[10px] h-[103.529px] items-start justify-start ml-0 mt-0 overflow-clip pb-[22px] pl-[13px] pr-[10px] pt-[13px] relative to-[rgba(246,246,246,0.5)] w-[222.037px]">
      <Frame758532680 />
    </div>
  );
}

function Group163() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] ml-0 mt-0 place-items-start relative">
      <Frame758532681 />
    </div>
  );
}

function Group162() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-0 mt-0 place-items-start relative">
      <Group163 />
    </div>
  );
}

function Group164() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-0 mt-0 place-items-start relative">
      <Group161 />
      <Group162 />
    </div>
  );
}

function Group173() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-0 mt-0 place-items-start relative">
      <Group164 />
    </div>
  );
}

function Group175() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-0 mt-0 place-items-start relative">
      <Group173 />
    </div>
  );
}

function Group176() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <Group175 />
    </div>
  );
}

function Group152() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0 text-black">
      <div className="[grid-area:1_/_1] flex flex-col font-['DM_Sans:Medium',_sans-serif] font-medium h-[17px] justify-center ml-0 mt-[8.5px] relative text-[22px] translate-y-[-50%] w-[103.333px]" style={{ fontVariationSettings: "'opsz' 14" }}>
        <p className="leading-[18px]">Agency</p>
      </div>
      <div className="[grid-area:1_/_1] flex flex-col font-['DM_Sans:ExtraLight',_sans-serif] font-extralight justify-center ml-0 mt-[48px] relative text-[0px] translate-y-[-50%] w-[155px]" style={{ fontVariationSettings: "'opsz' 14" }}>
        <p className="leading-[44px]">
          <span className="font-['DM_Sans:Light',_sans-serif] font-light text-[25px]" style={{ fontVariationSettings: "'opsz' 14" }}>
            $
          </span>
          <span className="font-['DM_Sans:ExtraLight',_sans-serif] font-extralight text-[20px]" style={{ fontVariationSettings: "'opsz' 14" }}>
            119
          </span>
          <span className="font-['DM_Sans:Bold',_sans-serif] font-bold text-[20px]" style={{ fontVariationSettings: "'opsz' 14" }}>
            {" "}
          </span>
          <span className="font-['DM_Sans:Light',_sans-serif] font-light text-[20px]" style={{ fontVariationSettings: "'opsz' 14" }}>
            /
          </span>
          <span className="font-['DM_Sans:ExtraLight',_sans-serif] font-extralight text-[20px]" style={{ fontVariationSettings: "'opsz' 14" }}>
            Per Month
          </span>
        </p>
      </div>
    </div>
  );
}

function Frame758532682() {
  return (
    <div className="absolute bg-gradient-to-b box-border content-stretch flex flex-col from-[rgba(180,165,251,0)] h-[108px] items-start justify-start left-0 overflow-clip pb-[15px] pt-[22px] px-[16px] rounded-tl-[13px] rounded-tr-[13px] to-[#ececec] top-0 via-0% via-[rgba(201,192,245,0)] w-[200px]">
      <Group152 />
      <div className="absolute inset-0 pointer-events-none shadow-[0px_4px_9.3px_-3px_inset_rgba(255,255,255,0.6)]" />
    </div>
  );
}

function Frame758532709() {
  return (
    <div className="bg-gradient-to-r box-border content-stretch flex from-[#6046e9] gap-[10px] h-[24px] items-center justify-center overflow-clip px-[10px] py-[2px] relative rounded-[6px] shrink-0 to-[rgba(96,70,233,0.67)] w-[113px]">
      <div className="flex flex-col font-['DM_Sans:SemiBold',_sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[9px] text-nowrap text-white" style={{ fontVariationSettings: "'opsz' 14" }}>
        <p className="leading-[27px] whitespace-pre">Select Plan</p>
      </div>
    </div>
  );
}

function Frame758532707() {
  return (
    <div className="absolute content-stretch flex flex-col h-[194px] items-center justify-center left-[2px] top-[108.5px] w-[200px]">
      <div className="flex flex-col font-['DM_Sans:Bold',_sans-serif] font-bold h-[20px] justify-center leading-[0] relative shrink-0 text-[#0b0707] text-[9px] text-center w-full" style={{ fontVariationSettings: "'opsz' 14" }}>
        <p className="leading-[27px]">Plan Highlights</p>
      </div>
      <div className="flex flex-col font-['DM_Sans:Light',_sans-serif] font-light h-[134px] justify-center leading-[0] relative shrink-0 text-[9px] text-black w-[180px]" style={{ fontVariationSettings: "'opsz' 14" }}>
        <p className="leading-[27px] whitespace-pre-wrap">
          <span className="font-['DM_Sans:Medium',_sans-serif] font-medium" style={{ fontVariationSettings: "'opsz' 14" }}>{` Content Downloads      `}</span>
          <span className="font-['DM_Sans:Bold',_sans-serif] font-bold" style={{ fontVariationSettings: "'opsz' 14" }}>
            {" "}
          </span>
          <span>
            500/month
            <br aria-hidden="true" />{" "}
          </span>
          <span className="font-['DM_Sans:Medium',_sans-serif] font-medium" style={{ fontVariationSettings: "'opsz' 14" }}>{`AI Video Generation        `}</span>
          <span>
            200 mins/month
            <br aria-hidden="true" />
          </span>
          <span className="font-['DM_Sans:Medium',_sans-serif] font-medium" style={{ fontVariationSettings: "'opsz' 14" }}>
            Virtual Photoshoots
          </span>
          <span>
            {`                              200`}
            <br aria-hidden="true" />
          </span>
          <span className="font-['DM_Sans:Medium',_sans-serif] font-medium" style={{ fontVariationSettings: "'opsz' 14" }}>
            Video Quality
          </span>
          <span>
            {`                   4K( if applicable)`}
            <br aria-hidden="true" />
          </span>
          <span className="font-['DM_Sans:Medium',_sans-serif] font-medium" style={{ fontVariationSettings: "'opsz' 14" }}>
            Brand Kits
          </span>
          <span>{`                                                 20`}</span>
        </p>
      </div>
      <Frame758532709 />
    </div>
  );
}

function Frame758532677() {
  return (
    <div className="bg-[rgba(255,255,255,0.9)] h-[300px] overflow-clip relative rounded-[13px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] shrink-0 w-[200px]">
      <Frame758532682 />
      <Frame758532707 />
    </div>
  );
}

function Frame758532694() {
  return (
    <div className="box-border content-stretch flex gap-[28px] items-center justify-center pb-0 pt-px px-0 relative shrink-0 w-[681px]">
      <Frame758532676 />
      <Group176 />
      <Frame758532677 />
    </div>
  );
}

export default function Frame758532715() {
  return (
    <div className="content-stretch flex flex-col items-center justify-start relative size-full">
      <Frame758532693 />
      <Frame758532694 />
    </div>
  );
}