// QuickAds SVG paths for checkmarks and icons
const svgPaths = {
  // Checkmark path for feature bullets
  pdf76300: "M1.5 4L4.5 7L10.5 1",
  p143fe00: "M1.5 4L5 7.5L13.5 1", 
  p9ccfb00: "M1.5 4L5 7.5L13.5 1"
};

export default svgPaths;