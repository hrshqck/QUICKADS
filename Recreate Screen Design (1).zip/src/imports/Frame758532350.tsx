import imgImage7 from "figma:asset/d56bcdda8fc35f40c10b5f01dbefae49f282b6e6.png";
import imgImage8 from "figma:asset/9dd87d57f5a18ace15aec6a7e36d0ec0d9a312b3.png";
import imgCitypngComNvidiaInceptionProgramLogoHdPng1000X10001 from "figma:asset/33744a915668a4401c8b7e393def2acb72dfaf72.png";
import imgImage6 from "figma:asset/ad105421b6f8feef8085bd7951cc02d94e2d1051.png";
import imgImage5 from "figma:asset/783d38e0b31a99768a70bbb672bbdaf9dcb1f804.png";

function Frame758532258() {
  return (
    <div className="content-stretch flex gap-[13.591px] h-[43px] items-center justify-center relative shrink-0 w-[661px]">
      <div className="bg-[50.4%_0%] bg-no-repeat bg-size-[132.3%_100%] h-[40px] shrink-0 w-[42px]" data-name="image 7" style={{ backgroundImage: `url('${imgImage7}')` }} />
      <div className="bg-center bg-cover bg-no-repeat h-[35px] shrink-0 w-[40px]" data-name="image 8" style={{ backgroundImage: `url('${imgImage8}')` }} />
      <div className="bg-left bg-no-repeat bg-size-[100%_304.3%] h-[36px] shrink-0 w-[94px]" data-name="[CITYPNG.COM]Nvidia Inception program Logo HD PNG - 1000x1000 1" style={{ backgroundImage: `url('${imgCitypngComNvidiaInceptionProgramLogoHdPng1000X10001}')` }} />
      <div className="bg-[48.66%_0%] bg-no-repeat bg-size-[116.61%_100%] h-[35px] shrink-0 w-[40px]" data-name="image 6" style={{ backgroundImage: `url('${imgImage6}')` }} />
      <div className="bg-center bg-cover bg-no-repeat h-[35px] shrink-0 w-[40px]" data-name="image 5" style={{ backgroundImage: `url('${imgImage5}')` }} />
      <div className="font-['DM_Sans:Bold',_sans-serif] font-bold leading-[0] relative shrink-0 text-[#6046e9] text-[12px] text-nowrap" style={{ fontVariationSettings: "'opsz' 14" }}>
        <p className="leading-[24px] whitespace-pre">{`& 20,000+ Happy Customers`}</p>
      </div>
    </div>
  );
}

export default function Frame758532350() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative size-full">
      <div className="font-['DM_Sans:Light',_sans-serif] font-light h-[27px] leading-[0] relative shrink-0 text-[14px] text-black text-center w-full" style={{ fontVariationSettings: "'opsz' 14" }}>
        <p className="leading-[28px]">{`Trusted by `}</p>
      </div>
      <Frame758532258 />
    </div>
  );
}