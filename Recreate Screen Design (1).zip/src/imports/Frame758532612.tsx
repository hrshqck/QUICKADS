import svgPaths from "./svg-zive2efl8j";
import imgImage from "figma:asset/7a6ea3d3fe335521d3921b252b8bd09d12da11f4.png";
import imgImage1 from "figma:asset/c0ca8f691725477f2e5bbf3481cd54166da2f08c.png";
import imgImage2 from "figma:asset/f71e74c544e10349110aa9ae41c38b0bd5248e9a.png";
import imgImage3 from "figma:asset/24a41fc546e634d820dd7b0ebd672b06be007594.png";
import imgImage4 from "figma:asset/4b0c0a651d6242e5b4472855f1da25ef2258f0c7.png";
import imgImage5 from "figma:asset/274d5e703a86b2d546304b4b4dca63420537800e.png";
import imgImage6 from "figma:asset/e847e4eaf305ade3473307cf81e0d7eb0b6f7843.png";

function Frame758532472() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-center justify-start relative shrink-0">
      <div className="font-['DM_Sans:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[#1a202c] text-[36px] text-center w-[658px]" style={{ fontVariationSettings: "'opsz' 14" }}>
        <p className="leading-[40px]">
          <span>{`Enter your website `}</span>
          <span className="bg-clip-text bg-gradient-to-r font-['DM_Sans:Bold',_sans-serif] font-bold from-[#6046e9] to-[#ff26c5] to-[83.654%]" style={{ WebkitTextFillColor: "transparent", fontVariationSettings: "'opsz' 14" }}>
            Link
          </span>
          <span>{` to start `}</span>
        </p>
      </div>
    </div>
  );
}

function Link() {
  return (
    <div className="relative shrink-0 size-[32px]" data-name="Link">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Link">
          <rect fill="white" fillOpacity="0.01" height="32" style={{ mixBlendMode: "multiply" }} width="32" />
          <g id="Vector">
            <path d={svgPaths.p1194d500} fill="black" />
            <path d={svgPaths.p15809e00} fill="black" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Frame758532560() {
  return (
    <div className="content-stretch flex gap-[16px] items-center justify-start relative shrink-0">
      <Link />
      <div className="flex flex-col font-['DM_Sans:Medium',_sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#718096] text-[16px] text-nowrap" style={{ fontVariationSettings: "'opsz' 14" }}>
        <p className="leading-[24px] whitespace-pre">Enter your website link to get started,</p>
      </div>
    </div>
  );
}

function ArrowUp() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Arrow Up">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Arrow Up">
          <path d={svgPaths.p726f4c0} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Button() {
  return (
    <div className="bg-gradient-to-t box-border content-stretch flex flex-col from-[#6046e9] gap-[4px] h-[98px] items-center justify-start p-[6px] relative rounded-[8px] to-[#7240b0]" data-name="Button">
      <ArrowUp />
      <div className="flex h-[60.656px] items-center justify-center relative shrink-0 w-[20px]">
        <div className="flex-none rotate-[270deg]">
          <div className="font-['Inter:Semi_Bold',_sans-serif] font-semibold leading-[0] not-italic relative text-[14px] text-nowrap text-white">
            <p className="leading-[20px] whitespace-pre">Continue</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function InputBoxWelcome() {
  return (
    <div className="bg-[rgba(255,255,255,0.94)] mb-[-14px] relative rounded-[16px] shrink-0 w-full z-[2]" data-name="input box_welcome">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex items-center justify-between p-[16px] relative w-full">
          <Frame758532560 />
          <div className="flex h-[32px] items-center justify-center relative shrink-0 w-[98px]">
            <div className="flex-none rotate-[90deg]">
              <Button />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function MdiWand() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="mdi:wand">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="mdi:wand">
          <path d={svgPaths.p163a800} fill="url(#paint0_linear_13_1420)" id="Vector" />
        </g>
        <defs>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_13_1420" x1="0.83125" x2="18.3333" y1="10.4177" y2="10.4177">
            <stop stopColor="#6046E9" />
            <stop offset="1" stopColor="#FF26C5" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
}

function Frame758532534() {
  return (
    <div className="bg-[#e1dbff] box-border content-stretch flex gap-[8px] h-[50px] items-center justify-center mb-[-14px] pb-0 pt-[14px] px-0 relative rounded-bl-[16px] rounded-br-[16px] shrink-0 w-full z-[1]">
      <MdiWand />
      <div className="font-['Inter:Medium',_sans-serif] font-medium leading-[0] not-italic relative shrink-0 text-[#6046e9] text-[14px] text-center text-nowrap">
        <p className="leading-[20px] whitespace-pre">Entering a URL saves 30 mins on brand setup</p>
      </div>
    </div>
  );
}

function Frame758532563() {
  return (
    <div className="box-border content-stretch flex flex-col isolate items-start justify-start pb-[14px] pt-0 px-0 relative shadow-[0px_0px_18px_-5px_rgba(0,0,0,0.15)] shrink-0 w-full">
      <InputBoxWelcome />
      <Frame758532534 />
    </div>
  );
}

function Frame758532308() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-center justify-center relative shrink-0">
      <div className="relative shrink-0 size-[40px]" data-name="image">
        <img className="block max-w-none size-full" height="40" src={imgImage} width="40" />
      </div>
      <div className="flex flex-col font-['DM_Sans:Medium',_sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[18px] text-black text-nowrap" style={{ fontVariationSettings: "'opsz' 14" }}>
        <p className="leading-[28px] whitespace-pre">Nike India</p>
      </div>
    </div>
  );
}

function Frame758532320() {
  return (
    <div className="bg-[rgba(255,255,255,0.8)] box-border content-stretch flex flex-col items-center justify-center overflow-clip p-[16px] relative rounded-[16px] shadow-[0px_0px_25px_0px_rgba(141,141,141,0.29)] shrink-0 size-[120px]">
      <Frame758532308 />
    </div>
  );
}

function Frame758532309() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-center justify-center relative shrink-0">
      <div className="relative shrink-0 size-[40px]" data-name="image">
        <img className="block max-w-none size-full" height="40" src={imgImage1} width="40" />
      </div>
      <div className="flex flex-col font-['DM_Sans:Medium',_sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[18px] text-black text-nowrap" style={{ fontVariationSettings: "'opsz' 14" }}>
        <p className="leading-[28px] whitespace-pre">{`H&M`}</p>
      </div>
    </div>
  );
}

function Frame758532321() {
  return (
    <div className="bg-[rgba(255,255,255,0.8)] box-border content-stretch flex flex-col items-center justify-center overflow-clip p-[16px] relative rounded-[16px] shadow-[0px_0px_25px_0px_rgba(141,141,141,0.29)] shrink-0 size-[120px]">
      <Frame758532309 />
    </div>
  );
}

function Frame758532343() {
  return (
    <div className="bg-white relative rounded-[80px] shrink-0">
      <div className="content-stretch flex gap-[10px] items-center justify-start overflow-clip relative">
        <div className="relative shrink-0 size-[40px]" data-name="image">
          <img className="block max-w-none size-full" height="40" src={imgImage2} width="40" />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#e6e6e6] border-solid inset-0 pointer-events-none rounded-[80px]" />
    </div>
  );
}

function Frame758532310() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-center justify-center relative shrink-0">
      <Frame758532343 />
      <div className="flex flex-col font-['DM_Sans:Medium',_sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[18px] text-black text-nowrap" style={{ fontVariationSettings: "'opsz' 14" }}>
        <p className="leading-[28px] whitespace-pre">Lululemon</p>
      </div>
    </div>
  );
}

function Frame758532323() {
  return (
    <div className="bg-[rgba(255,255,255,0.8)] box-border content-stretch flex flex-col items-center justify-center overflow-clip p-[16px] relative rounded-[16px] shadow-[0px_0px_25px_0px_rgba(141,141,141,0.29)] shrink-0 size-[120px]">
      <Frame758532310 />
    </div>
  );
}

function Frame758532311() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-center justify-center relative shrink-0">
      <div className="relative shrink-0 size-[40px]" data-name="image">
        <img className="block max-w-none size-full" height="40" src={imgImage3} width="40" />
      </div>
      <div className="flex flex-col font-['DM_Sans:Medium',_sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[18px] text-black text-nowrap" style={{ fontVariationSettings: "'opsz' 14" }}>
        <p className="leading-[28px] whitespace-pre">SKIMS</p>
      </div>
    </div>
  );
}

function Frame758532324() {
  return (
    <div className="bg-[rgba(255,255,255,0.8)] box-border content-stretch flex flex-col items-center justify-center overflow-clip p-[16px] relative rounded-[16px] shadow-[0px_0px_25px_0px_rgba(141,141,141,0.29)] shrink-0 size-[120px]">
      <Frame758532311 />
    </div>
  );
}

function Frame758532312() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-center justify-center relative shrink-0">
      <div className="relative shrink-0 size-[40px]" data-name="image">
        <img className="block max-w-none size-full" height="40" src={imgImage4} width="40" />
      </div>
      <div className="flex flex-col font-['DM_Sans:Medium',_sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[18px] text-black text-nowrap" style={{ fontVariationSettings: "'opsz' 14" }}>
        <p className="leading-[28px] whitespace-pre">Hims</p>
      </div>
    </div>
  );
}

function Frame758532325() {
  return (
    <div className="bg-[rgba(255,255,255,0.8)] box-border content-stretch flex flex-col items-center justify-center overflow-clip p-[16px] relative rounded-[16px] shadow-[0px_0px_25px_0px_rgba(141,141,141,0.29)] shrink-0 size-[120px]">
      <Frame758532312 />
    </div>
  );
}

function Frame758532313() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-center justify-center relative shrink-0">
      <div className="relative shrink-0 size-[40px]" data-name="image">
        <img className="block max-w-none size-full" height="40" src={imgImage5} width="40" />
      </div>
      <div className="flex flex-col font-['DM_Sans:Medium',_sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[18px] text-black text-nowrap" style={{ fontVariationSettings: "'opsz' 14" }}>
        <p className="leading-[28px] whitespace-pre">Pocket FM</p>
      </div>
    </div>
  );
}

function Frame758532322() {
  return (
    <div className="bg-[rgba(255,255,255,0.8)] box-border content-stretch flex flex-col items-center justify-center overflow-clip p-[16px] relative rounded-[16px] shadow-[0px_0px_25px_0px_rgba(141,141,141,0.29)] shrink-0 size-[120px]">
      <Frame758532313 />
    </div>
  );
}

function Frame758532340() {
  return (
    <div className="content-center flex flex-wrap gap-[16px] items-center justify-center relative shrink-0 w-full">
      <Frame758532320 />
      <Frame758532321 />
      <Frame758532323 />
      <Frame758532324 />
      <Frame758532325 />
      <Frame758532322 />
    </div>
  );
}

function Frame758532561() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-center justify-start relative shrink-0 w-full">
      <div className="font-['DM_Sans:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[#2d3748] text-[18px] text-center text-nowrap" style={{ fontVariationSettings: "'opsz' 14" }}>
        <p className="leading-[28px] whitespace-pre">In a hurry? Choose from these popular brands</p>
      </div>
      <Frame758532340 />
    </div>
  );
}

function Frame758532562() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-center justify-start relative shrink-0 w-[800px]">
      <Frame758532563 />
      <div className="flex flex-col font-['DM_Sans:Bold',_sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[16px] text-[rgba(0,0,0,0.8)] text-nowrap" style={{ fontVariationSettings: "'opsz' 14" }}>
        <p className="leading-[24px] whitespace-pre">Or</p>
      </div>
      <Frame758532561 />
    </div>
  );
}

function Frame758532543() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[40px] items-center justify-start left-1/2 top-1/2 translate-x-[-50%] translate-y-[-50%]">
      <Frame758532472 />
      <Frame758532562 />
    </div>
  );
}

function DefaultTrail() {
  return <div className="absolute left-0 size-[32px] top-0" data-name="Default Trail" />;
}

function Number() {
  return (
    <div className="absolute left-0 overflow-clip size-[32px] top-0" data-name="Number">
      <div className="absolute left-0 size-[32px] top-0" data-name="Circle">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
          <circle cx="16" cy="16" fill="var(--fill-0, #6046E9)" id="Circle" r="16" />
        </svg>
      </div>
      <div className="absolute font-['Inter:Medium',_sans-serif] font-medium leading-[0] left-1/2 not-italic text-[#f8f6ff] text-[13px] text-center text-nowrap translate-x-[-50%]" style={{ top: "calc(50% - 8.5px)" }}>
        <p className="leading-[normal] whitespace-pre">1</p>
      </div>
    </div>
  );
}

function StepSymbol() {
  return (
    <div className="absolute left-0 size-[32px] top-0" data-name="Step Symbol">
      <DefaultTrail />
      <Number />
    </div>
  );
}

function StepTextHorizontal() {
  return (
    <div className="relative self-stretch shrink-0 w-[32px]" data-name="Step Text - Horizontal">
      <StepSymbol />
      <div className="absolute font-['Inter:Bold',_sans-serif] font-bold leading-[0] left-[16.5px] not-italic text-[#6046e9] text-[13px] text-center text-nowrap top-[42px] translate-x-[-50%]">
        <p className="leading-[normal] whitespace-pre">Select Usecase</p>
      </div>
    </div>
  );
}

function StepTrail() {
  return (
    <div className="basis-0 grow h-[32px] min-h-px min-w-px relative shrink-0" data-name="Step Trail">
      <div className="absolute bg-[#dfd8fe] h-[2px] left-0 right-0 top-1/2 translate-y-[-50%]" data-name="Rect" />
    </div>
  );
}

function DefaultTrail1() {
  return <div className="absolute left-0 size-[32px] top-0" data-name="Default Trail" />;
}

function Number1() {
  return (
    <div className="absolute left-0 overflow-clip size-[32px] top-0" data-name="Number">
      <div className="absolute left-0 size-[32px] top-0" data-name="Circle">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
          <circle cx="16" cy="16" fill="var(--fill-0, #DFD8FE)" id="Circle" r="15" stroke="var(--stroke-0, #DFD8FE)" strokeWidth="2" />
        </svg>
      </div>
      <div className="absolute font-['Inter:Medium',_sans-serif] font-medium leading-[0] not-italic text-[#6046e9] text-[13px] text-center text-nowrap translate-x-[-50%]" style={{ top: "calc(50% - 8.5px)", left: "calc(50% - 0.5px)" }}>
        <p className="leading-[normal] whitespace-pre">2</p>
      </div>
    </div>
  );
}

function StepSymbol1() {
  return (
    <div className="absolute left-0 size-[32px] top-0" data-name="Step Symbol">
      <DefaultTrail1 />
      <Number1 />
    </div>
  );
}

function StepTextHorizontal1() {
  return (
    <div className="relative self-stretch shrink-0 w-[32px]" data-name="Step Text - Horizontal">
      <StepSymbol1 />
      <div className="absolute font-['Inter:Medium',_sans-serif] font-medium leading-[0] left-[16px] not-italic text-[13px] text-black text-center text-nowrap top-[42px] translate-x-[-50%]">
        <p className="leading-[normal] whitespace-pre">Add URL</p>
      </div>
    </div>
  );
}

function DefaultTrail2() {
  return <div className="absolute left-0 size-[32px] top-0" data-name="Default Trail" />;
}

function Number2() {
  return (
    <div className="absolute left-0 overflow-clip size-[32px] top-0" data-name="Number">
      <div className="absolute left-0 size-[32px] top-0" data-name="Circle">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
          <circle cx="16" cy="16" id="Circle" r="15" stroke="var(--stroke-0, #DFD8FE)" strokeWidth="2" />
        </svg>
      </div>
      <div className="absolute font-['Inter:Medium',_sans-serif] font-medium leading-[0] left-1/2 not-italic text-[13px] text-[rgba(0,0,0,0.64)] text-center text-nowrap translate-x-[-50%]" style={{ top: "calc(50% - 8.5px)" }}>
        <p className="leading-[normal] whitespace-pre">3</p>
      </div>
    </div>
  );
}

function StepSymbol2() {
  return (
    <div className="absolute left-0 size-[32px] top-0" data-name="Step Symbol">
      <DefaultTrail2 />
      <Number2 />
    </div>
  );
}

function StepTextHorizontal2() {
  return (
    <div className="relative self-stretch shrink-0 w-[32px]" data-name="Step Text - Horizontal">
      <StepSymbol2 />
      <div className="absolute font-['Inter:Medium',_sans-serif] font-medium leading-[0] left-[15.5px] not-italic text-[13px] text-black text-center text-nowrap top-[42px] translate-x-[-50%]">
        <p className="leading-[normal] whitespace-pre">Generate Creative</p>
      </div>
    </div>
  );
}

function StepperHorizontal() {
  return (
    <div className="absolute content-stretch flex items-start justify-start left-1/2 top-[40px] translate-x-[-50%] w-[342px]" data-name="Stepper Horizontal">
      <StepTextHorizontal />
      <StepTrail />
      <StepTextHorizontal1 />
      <StepTrail />
      <StepTextHorizontal2 />
    </div>
  );
}

export default function Frame758532612() {
  return (
    <div className="bg-[#f6f4ff] relative size-full">
      <div className="absolute h-[349px] left-[-303px] top-[468px] w-[602px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 602 349">
          <ellipse cx="301" cy="174.5" fill="var(--fill-0, #6046E9)" fillOpacity="0.61" id="Ellipse 139" rx="301" ry="174.5" />
        </svg>
      </div>
      <div className="absolute h-[349px] left-[1057px] top-[48px] w-[602px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 602 349">
          <ellipse cx="301" cy="174.5" fill="var(--fill-0, #6046E9)" fillOpacity="0.61" id="Ellipse 139" rx="301" ry="174.5" />
        </svg>
      </div>
      <div className="absolute h-[349px] translate-x-[-50%] translate-y-[-50%] w-[602px]" style={{ top: "calc(50% + 359.5px)", left: "calc(50% + 37px)" }}>
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 602 349">
          <ellipse cx="301" cy="174.5" fill="var(--fill-0, #FF00DD)" fillOpacity="0.14" id="Ellipse 140" rx="301" ry="174.5" />
        </svg>
      </div>
      <div className="absolute backdrop-blur-[325px] backdrop-filter bg-[rgba(255,255,255,0.2)] h-[899px] left-1/2 translate-x-[-50%] translate-y-[-50%] w-[1440px]" style={{ top: "calc(50% + 0.5px)" }} />
      <div className="absolute bg-center bg-cover bg-no-repeat h-[30px] left-[40px] top-[41px] w-[160px]" data-name="image 1" style={{ backgroundImage: `url('${imgImage6}')` }} />
      <Frame758532543 />
      <StepperHorizontal />
    </div>
  );
}