import { NitroContent } from "./components/NitroContent";
import { Button } from "./components/ui/button";
import { Play } from "lucide-react";

export default function App() {
  return (
    <div className="min-h-screen relative">
      {/* Background Gradient - fixed to cover entire viewport */}
      <div className="fixed inset-0 bg-gradient-to-br from-purple-100 via-pink-50 to-purple-200 -z-10" />
      
      {/* Watch Demo Floating Tag */}
      <div className="fixed right-0 top-1/2 transform -translate-y-1/2 z-50 origin-center">
        <Button
          variant="secondary"
          className="px-6 py-3 text-sm shadow-2xl backdrop-blur-md bg-purple-800/95 text-white hover:bg-purple-700 hover:shadow-xl transition-all duration-300 hover:scale-105 rounded-l-lg rounded-r-none border border-white/20 flex items-center gap-2 whitespace-nowrap"
        >
          <Play className="w-4 h-4" />
          Watch Demo
        </Button>
      </div>
      
      {/* Content Layer */}
      <div className="relative z-10">
        <NitroContent />
      </div>
    </div>
  );
}