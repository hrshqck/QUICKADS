import { Search, X } from "lucide-react";
import { Input } from "./ui/input";
import { Button } from "./ui/button";

export function Sidebar() {
  const userSettings = [
    "My Account",
    "Profiles", 
    "Content & Social",
    "Data & Privacy",
    "Family Center",
    "Authorized Apps",
    "Devices",
    "Connections",
    "Clips"
  ];

  const billingSettings = [
    "Nitro",
    "Server Boost", 
    "Subscriptions",
    "Gift Inventory",
    "Billing"
  ];

  const appSettings = [
    "Appearance",
    "Accessibility", 
    "Voice & Video",
    "Chat",
    "Notifications",
    "Keybinds",
    "Language"
  ];

  return (
    <div className="w-64 bg-[#2f3136] h-screen flex flex-col">
      {/* Header with Search */}
      <div className="p-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input 
            placeholder="Search" 
            className="pl-10 bg-[#202225] border-none text-white placeholder-gray-400 focus:ring-1 focus:ring-[#5865f2]"
          />
        </div>
      </div>

      {/* Navigation Sections */}
      <div className="flex-1 overflow-y-auto px-4">
        {/* User Settings */}
        <div className="mb-6">
          <h3 className="text-xs uppercase tracking-wide text-gray-400 mb-2">User Settings</h3>
          <div className="space-y-1">
            {userSettings.map((item) => (
              <button 
                key={item}
                className="w-full text-left px-2 py-1.5 text-gray-300 hover:bg-[#393c43] hover:text-white rounded text-sm"
              >
                {item}
              </button>
            ))}
          </div>
        </div>

        {/* Billing Settings */}
        <div className="mb-6">
          <h3 className="text-xs uppercase tracking-wide text-gray-400 mb-2">Billing Settings</h3>
          <div className="space-y-1">
            {billingSettings.map((item, index) => (
              <button 
                key={item}
                className={`w-full text-left px-2 py-1.5 rounded text-sm ${
                  index === 0 
                    ? "bg-[#5865f2] text-white" 
                    : "text-gray-300 hover:bg-[#393c43] hover:text-white"
                }`}
              >
                {item}
              </button>
            ))}
          </div>
        </div>

        {/* App Settings */}
        <div className="mb-6">
          <h3 className="text-xs uppercase tracking-wide text-gray-400 mb-2">App Settings</h3>
          <div className="space-y-1">
            {appSettings.map((item) => (
              <button 
                key={item}
                className="w-full text-left px-2 py-1.5 text-gray-300 hover:bg-[#393c43] hover:text-white rounded text-sm"
              >
                {item}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}