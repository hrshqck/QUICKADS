import { Button } from "./ui/button";
import { Card } from "./ui/card";
import {
  Sparkles,
  ArrowUp,
  Video,
  Users,
  Shield,
  Star,
  Clock,
  Check,
} from "lucide-react";
import { useState, useEffect } from "react";
import Frame758532350 from "../imports/Frame758532350";

export function NitroContent() {
  const [selectedPeriod, setSelectedPeriod] =
    useState("monthly");
  const [selectedCard, setSelectedCard] = useState<
    string | null
  >(null);
  const [timeLeft, setTimeLeft] = useState({
    hours: 23,
    minutes: 47,
    seconds: 32,
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return {
            ...prev,
            minutes: prev.minutes - 1,
            seconds: 59,
          };
        } else if (prev.hours > 0) {
          return {
            hours: prev.hours - 1,
            minutes: 59,
            seconds: 59,
          };
        }
        return prev;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="w-full relative">
      {/* Background glow effects - now more subtle to complement Figma background */}
      <div className="absolute h-[300px] left-[-200px] top-[200px] w-[400px] opacity-10">
        <div className="w-full h-full bg-gradient-to-r from-[#7A5AF8] to-[#6938EF] rounded-full blur-[100px]"></div>
      </div>
      <div className="absolute h-[250px] right-[-150px] top-[600px] w-[350px] opacity-10">
        <div className="w-full h-full bg-gradient-to-r from-[#6938EF] to-[#5925DC] rounded-full blur-[80px]"></div>
      </div>
      <div className="absolute h-[200px] left-1/2 top-[900px] w-[300px] opacity-10 transform -translate-x-1/2">
        <div className="w-full h-full bg-gradient-to-r from-[#9B8AFB] to-[#7A5AF8] rounded-full blur-[70px]"></div>
      </div>

      <div className="p-2 sm:p-4 max-w-6xl mx-auto relative z-10 w-full">
        {/* Main Hero Banner */}
        <div className="relative mb-4 p-3 sm:p-4 rounded-xl bg-gradient-to-br from-purple-200/60 via-purple-300/60 to-purple-400/60 sm:from-purple-200 sm:via-purple-300 sm:to-purple-400 overflow-hidden shadow-[0px_0px_40px_0px_rgba(147,51,234,0.25)] backdrop-blur-sm">
          {/* Decorative sparkles with glow */}
          <div className="absolute top-4 left-6">
            <Sparkles className="w-5 h-5 text-purple-700 opacity-80 drop-shadow-[0_0_8px_rgba(147,51,234,0.6)]" />
          </div>
          <div className="absolute top-8 left-12">
            <Sparkles className="w-3 h-3 text-purple-700 opacity-60 drop-shadow-[0_0_6px_rgba(147,51,234,0.4)]" />
          </div>
          <div className="absolute bottom-4 right-8">
            <Sparkles className="w-4 h-4 text-purple-700 opacity-70 drop-shadow-[0_0_8px_rgba(147,51,234,0.5)]" />
          </div>
          <div className="absolute bottom-8 right-6">
            <Sparkles className="w-3 h-3 text-purple-700 opacity-50 drop-shadow-[0_0_4px_rgba(147,51,234,0.3)]" />
          </div>

          {/* Gradient overlay for enhanced depth */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/10 to-transparent"></div>

          <div className="relative z-10 text-center text-black">
            <h1 className="text-xl md:text-2xl font-bold mb-2 drop-shadow-[0_2px_4px_rgba(0,0,0,0.3)] leading-tight">
              Unlock All Video Customisations and Features
            </h1>
            <p className="text-sm md:text-base mb-4 opacity-90 drop-shadow-[0_1px_2px_rgba(0,0,0,0.2)] max-w-2xl mx-auto">
              Buy a plan to edit, download and post your
              creatives.
            </p>

            <div className="flex flex-col md:flex-row justify-center items-center gap-3 md:gap-6 mb-4">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded-full bg-gradient-to-r from-[#6046E9] to-[#FF26C5] flex items-center justify-center">
                  <Check className="w-2.5 h-2.5 text-white" />
                </div>
                <div className="text-center">
                  <span className="text-xs md:text-sm font-semibold">
                    Instant videos from any link
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded-full bg-gradient-to-r from-[#6046E9] to-[#FF26C5] flex items-center justify-center">
                  <Check className="w-2.5 h-2.5 text-white" />
                </div>
                <div className="text-center">
                  <span className="text-xs md:text-sm font-semibold">
                    Google Veo 3 and Seedream models Integrations
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded-full bg-gradient-to-r from-[#6046E9] to-[#FF26C5] flex items-center justify-center">
                  <Check className="w-2.5 h-2.5 text-white" />
                </div>
                <div className="text-center">
                  <span className="text-xs md:text-sm font-semibold">
                    Access to stock footage and voice library
                  </span>
                </div>
              </div>
            </div>

            <div className="flex justify-center">
              
            </div>
          </div>
        </div>

        {/* Billing Period Selector */}
        <div className="flex justify-center mb-4">
          <div className="bg-white/70 backdrop-blur-md p-1 rounded-lg border border-white/20 shadow-[0px_0px_20px_0px_rgba(0,0,0,0.1)] backdrop-blur-sm">
            {["monthly", "yearly", "lifetime"].map((period) => (
              <button
                key={period}
                onClick={() => setSelectedPeriod(period)}
                className={`px-2 sm:px-3 py-1.5 text-xs rounded-md transition-all capitalize ${
                  selectedPeriod === period
                    ? "bg-[#7A5AF8] text-white shadow-[0_0_15px_rgba(122,90,248,0.5)] backdrop-blur-sm"
                    : "text-[#475467] hover:text-[#1D2939] hover:bg-white/50"
                }`}
              >
                {period}
              </button>
            ))}
          </div>
        </div>

        {/* Plan selection subtitle */}
        <div className="text-center mb-4 px-2">
          <p className="text-xs text-[#475467]">
            Choose the plan that suits you best, cancel anytime
          </p>
        </div>

        {/* Subscription Plans */}
        <div className="overflow-x-auto md:overflow-visible mb-6 mt-0 flex justify-center px-2">
          <div className="flex md:grid md:grid-cols-3 gap-3 md:gap-4 pb-4 md:pb-0 justify-center max-w-5xl mx-auto items-center min-w-max md:min-w-0">
            {/* Starter Plan */}
            <Card
              className={`p-2.5 border-none text-white relative overflow-hidden cursor-pointer transition-all duration-300 hover:scale-105 backdrop-blur-sm w-[240px] sm:w-[260px] md:w-[220px] lg:w-[240px] flex-shrink-0 ${
                selectedCard === "basic"
                  ? "bg-gradient-to-br from-[#6938EF] to-[#5925DC] ring-2 ring-white shadow-[0_0_30px_rgba(105,56,239,0.6)] backdrop-blur-md"
                  : "bg-gradient-to-br from-[#7A5AF8] to-[#9B8AFB] shadow-[0px_0px_30px_0px_rgba(122,90,248,0.25)] hover:shadow-[0px_0px_40px_0px_rgba(122,90,248,0.4)]"
              }`}
              onClick={() => setSelectedCard("basic")}
            >
              <div className="absolute top-2 right-2">
                <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center backdrop-blur-sm shadow-lg">
                  <span className="text-sm drop-shadow-md">
                    🚀
                  </span>
                </div>
              </div>

              <div className="mb-3">
                <h2 className="text-lg font-bold mb-1 drop-shadow-md">
                  Starter
                </h2>
                <p className="text-xs opacity-90 mb-2 drop-shadow-sm">
                  Perfect for small businesses getting started
                </p>
                <p className="text-base font-semibold drop-shadow-md">
                  $
                  {selectedPeriod === "monthly"
                    ? "63"
                    : selectedPeriod === "yearly"
                      ? "630"
                      : "1890"}
                  {selectedPeriod === "lifetime"
                    ? ""
                    : ` / ${selectedPeriod.slice(0, -2)}`}
                </p>
              </div>

              <div className="mb-4">
                {/* Feature list - vertical format */}
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <ArrowUp className="w-3 h-3 flex-shrink-0 drop-shadow-sm" />
                    <div className="flex-1">
                      <span className="text-xs drop-shadow-sm">
                        10 Downloads/month
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Video className="w-3 h-3 flex-shrink-0 drop-shadow-sm" />
                    <div className="flex-1">
                      <span className="text-xs drop-shadow-sm">
                        30 mins AI Video/month
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Users className="w-3 h-3 flex-shrink-0 drop-shadow-sm" />
                    <div className="flex-1">
                      <span className="text-xs drop-shadow-sm">
                        30 Virtual Photoshoots
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Shield className="w-3 h-3 flex-shrink-0 drop-shadow-sm" />
                    <div className="flex-1">
                      <span className="text-xs drop-shadow-sm">
                        SD (1920x1080)
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Star className="w-3 h-3 flex-shrink-0 drop-shadow-sm" />
                    <div className="flex-1">
                      <span className="text-xs drop-shadow-sm">
                        3 Brand Kits
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {selectedCard === "basic" && (
                <Button className="w-full bg-white text-[#6938EF] hover:bg-gray-100 py-1.5 text-sm shadow-lg hover:shadow-xl transition-all duration-300">
                  Select Plan
                </Button>
              )}
            </Card>

            {/* Pro Plan */}
            <Card
              className={`p-2.5 border-none text-white relative overflow-hidden cursor-pointer transition-all duration-300 hover:scale-105 backdrop-blur-sm w-[240px] sm:w-[260px] md:w-[220px] lg:w-[240px] flex-shrink-0 ${
                selectedCard === "pro"
                  ? "bg-gradient-to-br from-[#6938EF] to-[#5925DC] ring-2 ring-white shadow-[0_0_35px_rgba(105,56,239,0.7)] backdrop-blur-md"
                  : "bg-gradient-to-br from-[#7A5AF8] to-[#9B8AFB] shadow-[0px_0px_35px_0px_rgba(122,90,248,0.3)] hover:shadow-[0px_0px_45px_0px_rgba(122,90,248,0.5)]"
              }`}
              onClick={() => setSelectedCard("pro")}
            >
              <div className="absolute top-0 left-1/2 transform -translate-x-1/2">
                <div className="bg-white/20 px-2 py-0.5 rounded-b text-xs backdrop-blur-sm shadow-md">
                  Recommended
                </div>
              </div>
              <div className="absolute top-2 right-2">
                <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center backdrop-blur-sm shadow-lg">
                  <span className="text-sm drop-shadow-md">
                    ⭐
                  </span>
                </div>
              </div>

              <div className="mb-3 mt-1">
                <h2 className="text-lg font-bold mb-1 drop-shadow-md">
                  Pro Plan
                </h2>
                <p className="text-xs opacity-90 mb-2 drop-shadow-sm">
                  Advanced features for growing businesses
                </p>
                <p className="text-base font-semibold drop-shadow-md">
                  $
                  {selectedPeriod === "monthly"
                    ? "79"
                    : selectedPeriod === "yearly"
                      ? "790"
                      : "2370"}
                  {selectedPeriod === "lifetime"
                    ? ""
                    : ` / ${selectedPeriod.slice(0, -2)}`}
                </p>
              </div>

              <div className="mb-4">
                {/* Feature list - vertical format */}
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <ArrowUp className="w-3 h-3 flex-shrink-0 drop-shadow-sm" />
                    <div className="flex-1">
                      <span className="text-xs drop-shadow-sm">
                        60 Downloads/month
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Video className="w-3 h-3 flex-shrink-0 drop-shadow-sm" />
                    <div className="flex-1">
                      <span className="text-xs drop-shadow-sm">
                        60 mins AI Video/month
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Users className="w-3 h-3 flex-shrink-0 drop-shadow-sm" />
                    <div className="flex-1">
                      <span className="text-xs drop-shadow-sm">
                        80 Virtual Photoshoots
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Shield className="w-3 h-3 flex-shrink-0 drop-shadow-sm" />
                    <div className="flex-1">
                      <span className="text-xs drop-shadow-sm">
                        HD (1920x1080p)
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Star className="w-3 h-3 flex-shrink-0 drop-shadow-sm" />
                    <div className="flex-1">
                      <span className="text-xs drop-shadow-sm">
                        5 Brand Kits
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {selectedCard === "pro" && (
                <Button className="w-full bg-white text-[#6938EF] hover:bg-gray-100 py-1.5 text-sm shadow-lg hover:shadow-xl transition-all duration-300">
                  Select Plan
                </Button>
              )}
            </Card>

            {/* Agency Plan */}
            <Card
              className={`p-2.5 border-none text-white relative overflow-hidden cursor-pointer transition-all duration-300 hover:scale-105 backdrop-blur-sm w-[240px] sm:w-[260px] md:w-[220px] lg:w-[240px] flex-shrink-0 ${
                selectedCard === "agency"
                  ? "bg-gradient-to-br from-[#6938EF] to-[#5925DC] ring-2 ring-white shadow-[0_0_30px_rgba(105,56,239,0.6)] backdrop-blur-md"
                  : "bg-gradient-to-br from-[#7A5AF8] to-[#9B8AFB] shadow-[0px_0px_30px_0px_rgba(122,90,248,0.25)] hover:shadow-[0px_0px_40px_0px_rgba(122,90,248,0.4)]"
              }`}
              onClick={() => setSelectedCard("agency")}
            >
              <div className="absolute top-2 right-2">
                <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center backdrop-blur-sm shadow-lg">
                  <span className="text-sm drop-shadow-md">
                    🏢
                  </span>
                </div>
              </div>

              <div className="mb-3">
                <h2 className="text-lg font-bold mb-1 drop-shadow-md">
                  Agency
                </h2>
                <p className="text-xs opacity-90 mb-2 drop-shadow-sm">
                  Enterprise-grade for large organizations
                </p>
                <p className="text-base font-semibold drop-shadow-md">
                  $
                  {selectedPeriod === "monthly"
                    ? "119"
                    : selectedPeriod === "yearly"
                      ? "1190"
                      : "3570"}
                  {selectedPeriod === "lifetime"
                    ? ""
                    : ` / ${selectedPeriod.slice(0, -2)}`}
                </p>
              </div>

              <div className="mb-4">
                {/* Feature list - vertical format */}
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <ArrowUp className="w-3 h-3 flex-shrink-0 drop-shadow-sm" />
                    <div className="flex-1">
                      <span className="text-xs drop-shadow-sm">
                        500 Downloads/month
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Video className="w-3 h-3 flex-shrink-0 drop-shadow-sm" />
                    <div className="flex-1">
                      <span className="text-xs drop-shadow-sm">
                        200 mins AI Video/month
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Users className="w-3 h-3 flex-shrink-0 drop-shadow-sm" />
                    <div className="flex-1">
                      <span className="text-xs drop-shadow-sm">
                        200 Virtual Photoshoots
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Shield className="w-3 h-3 flex-shrink-0 drop-shadow-sm" />
                    <div className="flex-1">
                      <span className="text-xs drop-shadow-sm">
                        4K (if applicable)
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Star className="w-3 h-3 flex-shrink-0 drop-shadow-sm" />
                    <div className="flex-1">
                      <span className="text-xs drop-shadow-sm">
                        20 Brand Kits
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {selectedCard === "agency" && (
                <Button className="w-full bg-white text-[#6938EF] hover:bg-gray-100 py-1.5 text-sm shadow-lg hover:shadow-xl transition-all duration-300">
                  Select Plan
                </Button>
              )}
            </Card>
          </div>
        </div>

        {/* See all plan details link */}
        <div className="text-center mb-4">
          <button className="text-xs text-[#475467] hover:text-[#1D2939] transition-colors underline hover:drop-shadow-sm">
            see all plan details
          </button>
        </div>

        {/* Favorite Nitro Perks Section */}
        <div className="text-center">
          {/* This would typically contain more content, but keeping it simple for now */}
        </div>

        {/* Trusted By Section */}
        <div className="mb-8 px-2 sm:px-0">
          <Frame758532350 />
        </div>

        {/* Footer with Links */}
        <div className="text-center py-6 border-t border-white/20 px-2 sm:px-0">
          <div className="flex justify-center items-center gap-4 sm:gap-6 mb-4 flex-wrap">
            <a
              href="#"
              className="text-xs text-[#475467] hover:text-[#6046E9] transition-colors underline"
            >
              Terms & Conditions
            </a>
            <span className="text-[#475467] text-xs">•</span>
            <a
              href="#"
              className="text-xs text-[#475467] hover:text-[#6046E9] transition-colors underline"
            >
              Privacy Policy
            </a>
          </div>
          <p className="text-xs text-[#475467]">
            © 2024 QuickAds AI. All rights reserved.
          </p>
        </div>
      </div>
    </div>
  );
}